package com.example;

public interface MiniZoo {
    public abstract void badzMilutki();
}
